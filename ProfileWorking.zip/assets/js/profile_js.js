function showOverview() {
    // Скриваме секцията с настройки
    document.getElementById('settings').style.display = 'none';
    // Показваме секцията с преглед
    document.getElementById('overview').style.display = 'block';
    
    // Добавяме активен клас на бутона Overview
    document.querySelector('.btn-overview').classList.add('btn-active');
    document.querySelector('.btn-settings').classList.remove('btn-active');
}

function showSettings() {
    // Скриваме секцията с преглед
    document.getElementById('overview').style.display = 'none';
    // Показваме секцията с настройки
    document.getElementById('settings').style.display = 'block';
    
    // Добавяме активен клас на бутона Settings
    document.querySelector('.btn-settings').classList.add('btn-active');
    document.querySelector('.btn-overview').classList.remove('btn-active');
}

// Показваме секцията с преглед при зареждане на страницата
window.onload = function() {
    showOverview();
};

document.querySelectorAll('.button-group .btn').forEach(button => {
    button.addEventListener('click', function() {
        // Премахваме активния клас от всички бутони
        document.querySelectorAll('.button-group .btn').forEach(btn => btn.classList.remove('btn-active'));
        // Добавяме активния клас на натиснатия бутон
        this.classList.add('btn-active');
    });
});

function previewImage(event) {
    const file = event.target.files[0]; // Get the selected file
    const reader = new FileReader(); // Create a FileReader

    reader.onload = function(e) {
        const imgElement = document.getElementById('profile-img'); // Get the image element
        imgElement.src = e.target.result; // Set the new src for the image
    }

    if (file) {
        reader.readAsDataURL(file); // Read the file as a Data URL
    }
}